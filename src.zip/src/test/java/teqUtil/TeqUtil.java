package teqUtil;

public class TeqUtil {
	public static long PAGE_LOAD_TIMEOUT= 50;
	public static long IMPLICIT_WAIT= 50;
	
	public static String username= "admin@teq.app";	
	public static String password="QzT6*LgO#9";
	
	public static String ConfigFileLocationforWindows="\\src\\test\\java\\teqConfig\\ConfigProperties";
	public static String ConfigFileLocationforMac="/src/test/java/teqConfig/ConfigProperties";

	public static String ChromeDriverForWindowsLocation="\\Drivers\\chromedriver_Windows.exe";
	public static String ChromeDriverForMacLocation="/Drivers/chromedriver_Mac";
	
	public static String FirefoxDriverForWindowsLocation="\\Drivers\\geckodriver_Windows.exe";
	public static String FirefoxDriverForMacLocation="/Drivers/geckodriver_Mac";

}


