package teqPages;
import org.openqa.selenium.By;
//import org.openqa.selenium.support.FindBy;
import teqtestCases.TeqBase;

public class NewRequestPage {
	 public By loginField= By.name("username");
	 public By ContinueButton1= By.xpath("//button");
	 public By Password = By.id("password");
	 public By ContinueButton2= By.xpath("//button[@name=\"action\"]");
	 public By NewRequestBtn= By.xpath("//a[@class=\"btn\"]");
	 
	 
	 
	 //New Request ROUTE page
	 
	 public By PickupPoint= By.id("travel_from");
	 //public By PickupPoint= By.xpath("//input[@id='travel_from']");
	// public By Ppoint=By.xpath("");
	 public By DropOffPoint= By.id("travel_to");
	 public By DepartureDateTimeField= By.id("travel_datetime");
	 public By ArrivalDateTimeField= By.id("return_datetime");
	 public By SelectCustomerBtn= By.xpath("//button[@data-id='customer-id']");
	 public By CustomerSelectionDropdown= By.xpath("//ul[contains(@class,\"dropdown-menu inner show\")]//li//a//span");
	 public By pax= By.id("pax");
     public By MonthFieldSelector= By.xpath("/html/body/div[11]/div[1]/div[1]/div[1]/span");
     public By PastDateSelectorBtn= By.className("xdsoft_prev");
     public By FutureDateSelectorBtn=By.className("xdsoft_next");
     public By ViaPointButton= By.id("add-via-point-btn");
     public By NextStepButton= By.xpath("//div[contains(text(), \"Next Step\")]");
     public By AddReturnBtn=By.xpath("//button[contains(text(),\"Add return\")]");
     
     //public By Date =By.className("xdsoft_calender");
    
     
     

	//New Request PRICE page
     
    public By AddItemCostBtn= By.xpath("//button[contains(text(),\"Add Item Cost\")]");//Multiple
  //public By AddItemCost=By.xpath("//*[@id=\"price-per-order\"]/div[6]/div/button");
	
}
