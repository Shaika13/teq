package teqtestCases;
import teqPages.NewRequestPage;
import teqUtil.TeqUtil;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.testng.Assert;
import org.testng.annotations.Test;
public class TripTest extends TeqBase {

	@Test(priority=1)
	public void verifylogin() throws Exception{
        //initialization();
		newrequest = new NewRequestPage();
		verifyElementExists(driver,newrequest.loginField);
		verifyElementExists(driver, newrequest.ContinueButton1);
		newrequest = new NewRequestPage();
		entervalue(driver,newrequest.loginField,TeqUtil.username);
		clickElement(newrequest.ContinueButton1);
		verifyElementExists(driver, newrequest.ContinueButton2);
		entervalue(driver,newrequest.Password,TeqUtil.password);
		clickElement(newrequest.ContinueButton2);
		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		Thread.sleep(10000);
		clickElement(newrequest.NewRequestBtn);
		Thread.sleep(4000);
		String from="Dokka";
		String to="Kapp";
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);	
		//wait30sec();
		//waitForElementVisibility(newrequest.PickupPoint);
		verifyElementExists(driver,newrequest.PickupPoint);
		verifyElementExists(driver,newrequest.DropOffPoint);
		verifyElementExists(driver,newrequest.pax);

		
}
}
