package teqtestCases;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import java.util.Arrays;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.host.Map;

import org.openqa.selenium.WebElement;
import teqPages.*;
import teqUtil.*;
import org.openqa.selenium.support.ui.Select;
public class TeqBase {
	
	public static WebDriver driver;
	public static Properties prop;
	 public NewRequestPage newrequest;
	 
	//@BeforeClass 
	public static void initialization() {
		FileInputStream ip = null;
		final String ProjectPath= System.getProperty("user.dir");
		String os= System.getProperty("os.name").toLowerCase();
		//System.out.println(ProjectPath);
		//System.out.println(os);
		try {
			prop = new Properties();
			if(os.contains("windows")) {
			  ip = new FileInputStream(ProjectPath+TeqUtil.ConfigFileLocationforWindows);
			}
			else if(os.contains("mac")) {
			  ip = new FileInputStream(ProjectPath+TeqUtil.ConfigFileLocationforMac);
			}
			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	
		/*
		 //Method1 for chrome version >50 for Notification disabling
		  
		  
		//Create a map to store  preferences 
		HashMap<String, Object> prefs = new HashMap<String, Object>();

		//add key and value to map as follow to switch off browser notification
		//Pass the argument 1 to allow and 2 to block
		prefs.put("profile.default_content_setting_values.notifications", 0);

		//Create an instance of ChromeOptions 
		ChromeOptions options = new ChromeOptions();

		// set ExperimentalOption - prefs 
		options.setExperimentalOption("prefs", prefs);

		//Now Pass ChromeOptions instance to ChromeDriver Constructor to initialize chrome driver which will switch off this browser notification on the chrome browser
		//WebDriver driver = new ChromeDriver(options);

		
	*/	
	
		
	
		//Method2 for chrome version <50 for Notification disabling
		/*
		ChromeOptions options = new ChromeOptions();
	     options.addArguments("--disable-notifications");
*/
		 
		
		
	/*
	//Method3 for Notification disabling
		Robot robot = null;
		try {
			robot = new Robot();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		robot.delay(5000);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_ENTER);
*/
	
		
		/*
		 //Method 4 for Notification disabling
		  
		 ChromeOptions options=new ChromeOptions();
		 HashMap<String, Integer> contentSettings=new HashMap<String, Integer>();
		 HashMap<String, Object> profile=new HashMap<String, Object>();
		 HashMap<String, Object> prefs=new HashMap<String, Object>();
		 
		 // 0 for showing the pop up, 1 for allow, 2 for block
		 contentSettings.put("notifications", 1);
		 profile.put("managed_default_content_settings", contentSettings);
		 prefs.put("profile",profile);
		 options.setExperimentalOption("prefs", prefs);
		 
	*/
		
		
		/* Method 5 for notification disabling
		 ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("excludeSwitches",Arrays.asList("disable-popup-blocking"));
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability(ChromeOptions.CAPABILITY, options);
		 */

		String browsername= prop.getProperty("browser");
		
		if(browsername.equals("chrome") & os.contains("windows")) {
		System.setProperty("webdriver.chrome.driver",ProjectPath+TeqUtil.ChromeDriverForWindowsLocation);
		driver= new ChromeDriver();
		}
		else if(browsername.equals("chrome") & os.contains("mac")) {
			System.setProperty("webdriver.chrome.driver",ProjectPath+TeqUtil.ChromeDriverForMacLocation);
			driver= new ChromeDriver();
			}
		else if(browsername.equals("firefox") & os.contains("windows")) {
			System.setProperty("webdriver.gecko.driver",ProjectPath+TeqUtil.FirefoxDriverForWindowsLocation);
			driver= new FirefoxDriver();
			}
		else if(browsername.equals("firefox") & os.contains("mac")) {
			System.setProperty("webdriver.gecko.driver",ProjectPath+TeqUtil.FirefoxDriverForMacLocation);
			driver= new FirefoxDriver();
			}
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(TeqUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(TeqUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		driver.get(prop.getProperty("url"));
		}


	
	

	 public void wait30sec() throws Exception {
	        //new WebDriverWait(driver, 30).until(ExpectedConditions.presenceOfElementLocated(element));

//	        wait.until(ExpectedConditions.presenceOfElementLocated(element));

	        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	    }
	 
	 public void entervalue(WebDriver driver, By element, String value) throws Exception {

	       driver.findElement(element).sendKeys(new String[] { value });


//	        List<MobileElement> continueBtn = driver.findElements(element);
//	        for (MobileElement btn : continueBtn) {
	//
//	            Thread.sleep(5000);
//	            btn.sendKeys(new String[] { value });
//	            //btn.sendKeys(value);
	//
//	        }

	    }
	 
	 public static void verifyElementExists(WebDriver driver, By element)
	    {   
		    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	        boolean elementResult=driver.findElement(element).isDisplayed();


	        if(elementResult==true)
	        {
	            System.out.println("The ID: " +element+ "element is visible");
	        }
	        else
	        {
	            System.out.println("The ID: " +element+ "element is not visible");
	        }



	    }
	 public void clickElement (By element) throws  Exception{


//       List<MobileElement> continueBtn = driver.findElements(element);
//       for (MobileElement btn : continueBtn) {
//
//           btn.click();
//
//
//       }
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
       driver.findElement(element).click();
       Thread.sleep(3000);

   }
 @BeforeClass
	 public void verifylogin() throws Exception{
	        initialization();
			newrequest = new NewRequestPage();
			verifyElementExists(driver,newrequest.loginField);
			verifyElementExists(driver, newrequest.ContinueButton1);
			newrequest = new NewRequestPage();
			entervalue(driver,newrequest.loginField,TeqUtil.username);
			clickElement(newrequest.ContinueButton1);
			verifyElementExists(driver, newrequest.ContinueButton2);
			entervalue(driver,newrequest.Password,TeqUtil.password);
			clickElement(newrequest.ContinueButton2);
			
			
			Thread.sleep(10000);
			//driver.get("https://teq-test.teq.app/sales/request/direct/");
			//driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			//driver.findElement(By.id("generalSearch")).sendKeys("12345");
			 //System.out.println("Search found");
			 
			 driver.get("https://teq-test.teq.app/sales/request/new/");
			 
			
			
		}
 public static void verifyElementAndDataEntry(WebDriver driver2, By element,String value) throws Exception {
	 
	 boolean elementResult=driver2.findElement(element).isDisplayed();
     if(elementResult==true)
     {
         System.out.println("The ID: " +element+ "element is visible");
     }
     else
     {
         System.out.println("The ID: " +element+ "element is not visible");
     }
     driver2.findElement(element).sendKeys(new String[] { value });

	 
 }
 
 
 public void EnterPastOrFutureDateTime(WebDriver driver, By DateField,By MonthValField, By btn,String DateValue,String MonthValue, String TimeValue) throws InterruptedException {
	 
	 driver.findElement(DateField).click();
	 Thread.sleep(2000);
	  while(true) {
		  
	 String text=driver.findElement(MonthValField).getText();
	 if (text.equals(MonthValue))
	 {
		 break;
	 
	 }
	 else
	 {
		 driver.findElement(btn).click();
	 }
	 
	  }
	  driver.findElement(By.xpath("/html/body/div[11]/div[1]/div[2]/table/tbody/tr/td/div[contains(text(),"+DateValue+")]")).click();
	 driver.findElement(By.xpath("/html/body/div[11]/div[2]/div/div[1]/div[contains(text(),"+TimeValue+")]")).click();
 }
 
 public void CustomerSelectionFromDropdown(WebDriver driver, By element1,By element2,String value)
 {
	 driver.findElement(element1).click();
	 List<WebElement> list=driver.findElements(element2);
	 for (int i=0; i<list.size(); i++)
	 {
		 if(list.get(i).getText().contains(value))
		 {
			 list.get(i).click();
			 break;
			 
		 }
	 }
	 
 }
 
 public void LocationSelectionFromDropdown(WebDriver driver,By element2,String value)
 {
	 List<WebElement> list=driver.findElements(element2);
	 for (int i=0; i<list.size(); i++)
	 {
		 if(list.get(i).getText().contains(value))
		 {
			 list.get(i).click();
			 break;
			 
		 }
	 }
	 
 }
 
 
 public void waitForElementVisibility(By by) {
	 WebDriverWait webDriverWait = new WebDriverWait(null, 0);
	webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}
 

	//@AfterTest
    public void closeTheApp( )  {
        driver.close();
    }	
	
//
}

