package teqtestCases;

import org.testng.annotations.Test;
import teqPages.NewRequestPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;


import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;



import java.util.List;
import java.util.concurrent.TimeUnit;

public class NewRequestTest extends TeqBase {
	
	 public NewRequestPage newrequest;

	@Test(priority = 0)
	    public void testloginpage() throws Exception
	    {   
		
		   //driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	        newrequest = new NewRequestPage();
	        System.out.println("========= Getting Started ==========");

	    }
	
	@Test(priority=1)
	public void createSingleTrip() throws Exception
	{
		
		newrequest=new NewRequestPage();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		//wait30sec();
		//clickElement(newrequest.NewRequestBtn);
		//Thread.sleep(4000);
		//driver.navigate().refresh();
			
	}

	@Test(priority=2)
	public void trip() throws Exception
	{   
		newrequest=new NewRequestPage();
		String from="Dokka, Norway";
		String to="Kapp, Norway";
		String pax="10";
		String Customer="customer013";
		String date="06";
		String Month="September";
		String time="18:00";
		String datetime="16.10.2021 18;34";
	
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);	
		wait30sec();
		//waitForElementVisibility(newrequest.PickupPoint);
				//verifyElementExists(driver,newrequest.DropOffPoint);
		//verifyElementExists(driver,newrequest.pax);
		//verifyElementExists(driver,newrequest.NewRequestBtn);
	//clickElement(newrequest.NewRequestBtn);
		//Thread.sleep(4000);
		 //driver.findElement(By.id("travel_from")).sendKeys("Jaren");
		verifyElementAndDataEntry(driver,newrequest.PickupPoint, from);
		verifyElementAndDataEntry(driver,newrequest.DropOffPoint, to);
		verifyElementAndDataEntry(driver,newrequest.DepartureDateTimeField, datetime);
		
		//EnterPastOrFutureDateTime(driver,newrequest.DepartureDateTimeField,newrequest.MonthFieldSelector,newrequest.FutureDateSelectorBtn,date,Month,time);
		CustomerSelectionFromDropdown(driver,newrequest.SelectCustomerBtn, newrequest.CustomerSelectionDropdown,Customer);
		verifyElementAndDataEntry(driver,newrequest.pax, pax);
		
		clickElement(newrequest.NextStepButton);
		
		
		
		
	}
}

	
